package br.com.serratec.banco;

public enum Transacao {
	
	SAQUE(0.10),
	DEPOSITO(0.10),
	TRANSFERENCIA(0.20);
	
	private double valorPorTransacao;

	private Transacao(double valorPorTransacao) {
		this.valorPorTransacao = valorPorTransacao;
	}
	public double getValorPorTransacao() {
		return valorPorTransacao;
	}
}